(function () {
	
  'use strict';

  angular.module("myApp")
	.config(config);
  

  config.$inject = ['$stateProvider','$urlRouterProvider'];
	   
  function config($stateProvider, $urlRouterProvider){

 
  	 $urlRouterProvider
     .otherwise("/login")


    
  	 $stateProvider

    .state('login',
     {
       url: '/login',
      templateUrl: "views/login.html",
      controller: 'logController',
    })
    
    .state('/signup', {
        
        url: '/signup',
        templateUrl: "views/signup.html",
        controller:  'signController',
    })

    .state('/adbook', {
        
        url: '/adbook',
        templateUrl: "views/adbook.html",
        controller:  'conController',
    })
     .state('/adbokreg', {
        
         url: '/adbokreg',
         templateUrl: "views/adbokreg.html",
         controller:  'conController',
     })

     .state('/contacts', {
        
         url: '/contacts',
         templateUrl: "views/contacts.html",
         controller:  'regbukController',
     })

}
})();


 
 	 angular.module('myApp')
 	.controller('logController', logController)
 	.controller('signController', signController);
 	
 	logController.$inject = ['$scope','$location','$http','$rootScope'];

	function logController($scope, $location, $http, $rootScope) {

		$scope.user = {};
		$scope.loginError = '';

		$scope.login = function () {
		

			console.log($scope.user);
			$http.post('http://localhost:4516/api/users/login',$scope.user)
			.then(function (res) {

					console.log(JSON.stringify(res));
					$scope.user = res;
				//if(res)
			//	{	
					$location.path('/adbook');
			//	}
		
		}, 

			function (res) {

			$scope.loginError = 'Email or password is wrong';
		});
	}
};


 		signController.$inject = ['$scope', '$location', '$http'];
 		function signController($scope, $location, $http) {

 		$scope.user = {};
 		$scope.signup = function() {

 			
 			$http.post('http://localhost:4516/api/users', {

 				email: $scope.user.email,
 				password: $scope.user.password
				
 			})

 				.then(function (res){
 				console.log(JSON.stringify(res));

 				if(res) {
					
					$location.path('/login');
 				}

 				}, function (res){
                 
                 console.log(res);
 					//log error
 				});
 		}

 };


	


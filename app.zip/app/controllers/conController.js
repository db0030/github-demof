	 angular.module("myApp")
	.controller('conController',conController)
	.controller('regbukController',regbukController);

	
	conController.$inject = ['$scope', '$location', '$http', '$rootScope'];
	function conController($scope,$location, $http, $rootScope) {

			
			$scope.getbook = function () {

				$location.path('/adbokreg');

			}
		};

	
	
	regbukController.$inject = ['$scope','$location','$http', '$rootScope'];
	function regbukController($scope, $location, $http, $rootScope){

			
			$scope.contact = {};
			


			$scope.adbuksub = function(){

			console.log($scope.contact);
			$http.post('http://localhost:4516/api/AddressBooks' , {

 				name: $scope.contact.name
 							
 			})

 				.then (function (res)
 				{
 				
 					//console.log(JSON.stringify(res));
					if(res) 
					{
						$location.path('/contacts');
 					}
				}, 

				function(res)
				{
                 	console.log(res);
 					//log error
 				});
 		}
};

	


		
		




	
	

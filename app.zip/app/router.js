
	angular.module('myApp',['ngRoute'])
	.config(config);
  config.$inject=['$stateProvider','$urlRouterProvider'];
	   
  function config($stateProvider, $urlRouterProvider){

	// For any unmatched url, redirect to /state1 
  	 $urlRouterProvider.otherwise("/login")


   // Now set up the states 
  	 $stateProvider

    .state('login',
    {
      url: "/login",
      templateUrl: "views/login.html",
      
    })
    

    .state('orders', {
        
        url: "/orders/:customerId",
        templateUrl: "views/signup.html",
        controller:  '',
    })


	}

